print("Client: ")
userInput = ""
server = "localhost"
port = "8000"

while(userInput != "exit"):
	userInput = input("@ ")
	
	if(userInput == "server"):
		print("server " + localhost + 8000)
	else if(userInput == "client"):
		print("Rock, Paper and Scissors image classification server.:)
		print(Ricardo Lizarraga)